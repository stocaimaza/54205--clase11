//1) UTILIZANDO PROPS

// const Nieto = ({ herencia }) => {
//     return (
//         <div>
//             <p>Mi herencia es de {herencia.efectivo} </p>
//             <p>Uso estos vehiculos: {herencia.vehiculos} </p>
//             <p>Y estoy usando estas propiedades {herencia.propiedades} </p>
//         </div>
//     )
// }

// export default Nieto

//2) UTILIZANDO EL CONSUMER 

// import React from 'react'
// import { Contexto } from '../../context/context';

// const Nieto = () => {
//   return (
//     <Contexto.Consumer>
//         {/* Para poder acceder a la información tengo que usar una función de renderizado*/}

//         {
//             (herencia) => (
//                 <div>
//                     <p>Efectivo: {herencia.efectivo} </p>
//                     <p>Vehiculos: {herencia.vehiculos} </p>
//                     <p>Casas: {herencia.propiedades} </p>
//                 </div>
//             )
//         }

//     </Contexto.Consumer>
//   )
// }

// export default Nieto

/* TENEMOS UN NUEVO ROBIN HOOK */
/** useContext **/

//En lugar de usar el Consumer y una función de renderizado yo puedo utilizar el hook llamado "useContext". 

import React from 'react';

//1) Importamos el Contexto
import { Contexto } from '../../context/context';
//2) Importamos el Hook
import { useContext } from 'react';



const Nieto = () => {

    const herencia = useContext(Contexto);
    //3) Creamos una variable que almacene el valor del contexto. 

  return (
    <div>
        <p>Me gasté este efectivo: {herencia.efectivo} </p>
        <p>Choque estos autos: {herencia.vehiculos} </p>
        <p>Mal vendí estas casas: {herencia.propiedades} </p>
    </div>
  )
}

export default Nieto