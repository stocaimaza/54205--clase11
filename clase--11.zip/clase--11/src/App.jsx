//Aprendimos en estas clases que podemos enviar información entre componentes a traves de las props. Pero estas se envian de forma unidireccional de un componente padre a un componente hijo. 
//Esto en aplicaciones grandes con muchas capas de componentes se convierte en una tarea tediosa.


//Ejemplo: Herencia Familiar 

import Abuelo from "./componentes/Abuelo/Abuelo";

//Voy a importar el contexto: 

import { Contexto } from "./context/context";


const App = () => {

  const herencia = {
    efectivo: 100000000,
    propiedades: 20, 
    vehiculos: 40
  }

  return (
    <div>

      <Contexto.Provider value={herencia}>
        <Abuelo />
      </Contexto.Provider>



    </div>
  )
}

export default App